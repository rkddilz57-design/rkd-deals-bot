import { useState } from "react";
import {
  ShieldCheck,
  Lock,
  Zap,
  Gift,
  Users,
  CreditCard,
  Link2,
  Headphones,
  Globe,
  ChevronDown,
  ChevronRight,
} from "lucide-react";

const BOT_USERNAME = "garantnftrdkBot";
const BOT_URL = `https://t.me/${BOT_USERNAME}`;

type Lang = "ru" | "en";

const COPY: Record<
  Lang,
  {
    badgeOnline: string;
    heroTitleLine1: string;
    heroTitleLine2: string;
    heroSubtitle: string;
    heroCta: string;
    pillGuarantee: string;
    pillPayment: string;
    pillNotify: string;
    statUsers: string;
    statDeals: string;
    statNft: string;
    statSuccess: string;
    featuresEyebrow: string;
    featuresTitle: string;
    feature1Title: string;
    feature1Desc: string;
    feature2Title: string;
    feature2Desc: string;
    feature3Title: string;
    feature3Desc: string;
    feature4Title: string;
    feature4Desc: string;
    processEyebrow: string;
    processTitle: string;
    step1Title: string;
    step1Desc: string;
    step2Title: string;
    step2Desc: string;
    step3Title: string;
    step3Desc: string;
    step4Title: string;
    step4Desc: string;
    ctaTitle: string;
    ctaButton: string;
    footerTagline: string;
    footerBot: string;
    footerSupport: string;
    navReferral: string;
    navSupport: string;
  }
> = {
  ru: {
    badgeOnline: "ОНЛАЙН · ГАРАНТ АКТИВЕН 24/7",
    heroTitleLine1: "P2P-сделки под защитой",
    heroTitleLine2: "гаранта",
    heroSubtitle:
      "Безопасный обмен крипты, фиата и NFT. Никаких рисков — только гарантированный результат.",
    heroCta: "Как это работает",
    pillGuarantee: "Гарант-протокол",
    pillPayment: "Защищённая оплата",
    pillNotify: "Мгновенные уведомления",
    statUsers: "АКТИВНЫХ ПОЛЬЗОВАТЕЛЕЙ",
    statDeals: "ЗАВЕРШЁННЫХ СДЕЛОК",
    statNft: "NFT-ОБМЕНА",
    statSuccess: "УСПЕШНЫХ СДЕЛОК",
    featuresEyebrow: "ВОЗМОЖНОСТИ",
    featuresTitle: "Всё для сделки в одном боте",
    feature1Title: "Умные сделки",
    feature1Desc: "Создайте P2P оффер за пару минут, бот сам сгенерирует ссылку для покупателя.",
    feature2Title: "Обмен NFT",
    feature2Desc: "Гарантированный обмен Telegram-подарками между двумя пользователями.",
    feature3Title: "Реферальная сеть",
    feature3Desc: "Приглашайте по личной ссылке и зарабатывайте процент с их сделок.",
    feature4Title: "Кошельки и карты",
    feature4Desc: "TON + банковские карты, 12 валют (TON, RUB, UAH, EUR, USD...).",
    processEyebrow: "МЕХАНИЗМ ДЕЙСТВИЯ",
    processTitle: "Четыре шага до завершения сделки",
    step1Title: "Создание сделки",
    step1Desc: "Продавец указывает сумму, валюту и описание; бот генерирует ссылку.",
    step2Title: "Подключение покупателя",
    step2Desc: "Покупатель открывает ссылку, бот привязывает его к сделке.",
    step3Title: "Оплата через гарант",
    step3Desc: "Бот выдаёт реквизиты; гарант переводит статус в «Оплачено».",
    step4Title: "Завершение",
    step4Desc: "Продавец передаёт товар; покупатель подтверждает; средства разблокируются.",
    ctaTitle: "Готовы провести сделку?",
    ctaButton: `Открыть @${BOT_USERNAME}`,
    footerTagline: "Надёжный P2P-гарант в Telegram для безопасных сделок",
    footerBot: "Бот",
    footerSupport: "Поддержка",
    navReferral: "Реферальная программа",
    navSupport: "Поддержка",
  },
  en: {
    badgeOnline: "ONLINE · GUARANTOR ACTIVE 24/7",
    heroTitleLine1: "P2P deals under the",
    heroTitleLine2: "guarantor's protection",
    heroSubtitle:
      "Safe exchange of crypto, fiat and NFTs. No risk — only a guaranteed result.",
    heroCta: "How it works",
    pillGuarantee: "Guarantor protocol",
    pillPayment: "Protected payment",
    pillNotify: "Instant notifications",
    statUsers: "ACTIVE USERS",
    statDeals: "COMPLETED DEALS",
    statNft: "NFT SWAPS",
    statSuccess: "SUCCESSFUL DEALS",
    featuresEyebrow: "FEATURES",
    featuresTitle: "Everything for a deal in one bot",
    feature1Title: "Smart deals",
    feature1Desc: "Create a P2P offer in a couple of minutes — the bot generates a link for the buyer.",
    feature2Title: "NFT exchange",
    feature2Desc: "Guaranteed exchange of Telegram gifts between two users.",
    feature3Title: "Referral network",
    feature3Desc: "Invite with your personal link and earn a percentage of their deals.",
    feature4Title: "Wallets & cards",
    feature4Desc: "TON + bank cards, 12 currencies (TON, RUB, UAH, EUR, USD...).",
    processEyebrow: "HOW IT WORKS",
    processTitle: "Four steps to complete a deal",
    step1Title: "Create the deal",
    step1Desc: "The seller enters the amount, currency and description; the bot generates a link.",
    step2Title: "Buyer joins",
    step2Desc: "The buyer opens the link, the bot links them to the deal.",
    step3Title: "Payment via guarantor",
    step3Desc: "The bot issues requisites; the guarantor sets the status to \"Paid\".",
    step4Title: "Completion",
    step4Desc: "The seller delivers the item; the buyer confirms; funds are released.",
    ctaTitle: "Ready to make a deal?",
    ctaButton: `Open @${BOT_USERNAME}`,
    footerTagline: "A reliable P2P guarantor on Telegram for safe deals",
    footerBot: "Bot",
    footerSupport: "Support",
    navReferral: "Referral program",
    navSupport: "Support",
  },
};

function openBot() {
  const tg = (window as any).Telegram?.WebApp;
  if (tg?.openTelegramLink) {
    tg.openTelegramLink(BOT_URL);
  } else {
    window.open(BOT_URL, "_blank");
  }
}

function scrollToFeatures() {
  document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
}

export default function Home() {
  const [lang, setLang] = useState<Lang>("ru");
  const t = COPY[lang];

  return (
    <div className="min-h-screen bg-background text-foreground pb-24">
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400">
              <ShieldCheck className="h-4.5 w-4.5 text-white" size={18} />
            </div>
            <span className="text-[15px] font-bold tracking-tight">RKD Deals</span>
          </div>
          <button
            onClick={() => setLang(lang === "ru" ? "en" : "ru")}
            data-testid="button-lang-toggle"
            className="flex items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-3.5 py-1.5 text-xs font-semibold text-secondary-foreground hover-elevate active-elevate-2"
          >
            <Globe size={13} />
            {lang.toUpperCase()}
          </button>
        </div>
      </header>

      <section className="relative overflow-hidden px-5 pt-14 pb-10 text-center">
        <div
          className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[420px] -translate-x-1/2 rounded-full opacity-20 blur-[100px]"
          style={{ background: "radial-gradient(circle, hsl(217 91% 60%), transparent 70%)" }}
        />
        <div className="relative mx-auto max-w-2xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-4 py-1.5 text-[11px] font-semibold tracking-wide text-emerald-400">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </span>
            {t.badgeOnline}
          </div>

          <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl">
            <span className="text-foreground">{t.heroTitleLine1}</span>{" "}
            <span
              className="block bg-gradient-to-r from-blue-400 via-sky-400 to-cyan-300 bg-clip-text text-transparent"
              style={{ filter: "drop-shadow(0 0 24px hsl(217 91% 60% / 0.35))" }}
            >
              {t.heroTitleLine2}
            </span>
          </h1>

          <p className="mx-auto mt-5 max-w-md text-[15px] leading-relaxed text-muted-foreground">
            {t.heroSubtitle}
          </p>

          <button
            onClick={scrollToFeatures}
            data-testid="button-hero-cta"
            className="mt-8 inline-flex items-center gap-2 rounded-xl bg-amber-400 px-7 py-3.5 text-[15px] font-bold text-amber-950 shadow-lg shadow-amber-500/20 hover-elevate active-elevate-2"
          >
            {t.heroCta}
            <ChevronDown size={17} />
          </button>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-2.5">
            <Pill icon={<ShieldCheck size={13} />} label={t.pillGuarantee} />
            <Pill icon={<Lock size={13} />} label={t.pillPayment} />
            <Pill icon={<Zap size={13} />} label={t.pillNotify} />
          </div>
        </div>
      </section>

      <section className="px-5">
        <div className="mx-auto grid max-w-4xl grid-cols-2 gap-4 rounded-2xl border border-card-border bg-card p-6 sm:grid-cols-4 sm:gap-6">
          <Stat value="3728" label={t.statUsers} />
          <Stat value="8097" label={t.statDeals} />
          <Stat value="7348" label={t.statNft} />
          <Stat value="97%" label={t.statSuccess} />
        </div>
      </section>

      <section id="features" className="mx-auto max-w-4xl px-5 pt-16">
        <div className="text-center">
          <span className="inline-block rounded-full border border-amber-400/30 bg-amber-400/10 px-3.5 py-1 text-[11px] font-bold tracking-wide text-amber-400">
            {t.featuresEyebrow}
          </span>
          <h2 className="mt-4 text-2xl font-extrabold tracking-tight sm:text-3xl">
            {t.featuresTitle}
          </h2>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <FeatureCard icon={<ShieldCheck size={20} />} title={t.feature1Title} desc={t.feature1Desc} bgIcon={<ShieldCheck size={72} />} />
          <FeatureCard icon={<Gift size={20} />} title={t.feature2Title} desc={t.feature2Desc} bgIcon={<Gift size={72} />} />
          <FeatureCard icon={<Users size={20} />} title={t.feature3Title} desc={t.feature3Desc} bgIcon={<Users size={72} />} />
          <FeatureCard icon={<CreditCard size={20} />} title={t.feature4Title} desc={t.feature4Desc} bgIcon={<CreditCard size={72} />} />
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-5 pt-16">
        <div className="text-center">
          <span className="inline-block rounded-full border border-amber-400/30 bg-amber-400/10 px-3.5 py-1 text-[11px] font-bold tracking-wide text-amber-400">
            {t.processEyebrow}
          </span>
          <h2 className="mt-4 text-2xl font-extrabold tracking-tight sm:text-3xl">
            {t.processTitle}
          </h2>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <StepCard num="01" title={t.step1Title} desc={t.step1Desc} />
          <StepCard num="02" title={t.step2Title} desc={t.step2Desc} />
          <StepCard num="03" title={t.step3Title} desc={t.step3Desc} />
          <StepCard num="04" title={t.step4Title} desc={t.step4Desc} />
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 pt-16">
        <div className="rounded-2xl border border-card-border bg-gradient-to-b from-card to-card/60 px-6 py-12 text-center">
          <h2 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{t.ctaTitle}</h2>
          <button
            onClick={openBot}
            data-testid="button-open-bot"
            className="mt-6 inline-flex items-center gap-1.5 rounded-xl bg-sky-500 px-6 py-3.5 text-[15px] font-bold text-white shadow-lg shadow-sky-500/25 hover-elevate active-elevate-2"
          >
            {t.ctaButton}
            <ChevronRight size={17} />
          </button>
        </div>
      </section>

      <footer className="mx-auto mt-16 max-w-4xl border-t border-border/60 px-5 py-10">
        <div className="flex flex-col items-center justify-between gap-6 text-center sm:flex-row sm:text-left">
          <div>
            <div className="flex items-center justify-center gap-2.5 sm:justify-start">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400">
                <ShieldCheck className="text-white" size={15} />
              </div>
              <span className="text-sm font-bold">RKD Deals</span>
            </div>
            <p className="mt-2 max-w-xs text-[13px] text-muted-foreground">{t.footerTagline}</p>
          </div>
          <div className="flex flex-col items-center gap-2 sm:items-end">
            <div className="flex gap-5 text-[13px] text-muted-foreground">
              <a href={BOT_URL} target="_blank" rel="noopener noreferrer" className="hover:text-foreground" data-testid="link-footer-bot">
                {t.footerBot}
              </a>
              <a href={`https://t.me/RkdGarant`} target="_blank" rel="noopener noreferrer" className="hover:text-foreground" data-testid="link-footer-support">
                {t.footerSupport}
              </a>
            </div>
            <p className="text-[11px] text-muted-foreground/60">© 2026 RKD Deals</p>
          </div>
        </div>
      </footer>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center justify-around py-2.5">
          <button
            onClick={() => {
              const tg = (window as any).Telegram?.WebApp;
              const uid = tg?.initDataUnsafe?.user?.id;
              const url = `${BOT_URL}?start=ref_${uid ?? ""}`;
              if (tg?.openTelegramLink) tg.openTelegramLink(url);
              else window.open(url, "_blank");
            }}
            data-testid="button-nav-referral"
            className="flex flex-col items-center gap-1 px-3 py-1 text-[11px] text-muted-foreground hover:text-foreground"
          >
            <Link2 size={17} />
            {t.navReferral}
          </button>
          <a
            href="https://t.me/RkdGarant"
            target="_blank"
            rel="noopener noreferrer"
            data-testid="link-nav-support"
            className="flex flex-col items-center gap-1 px-3 py-1 text-[11px] text-muted-foreground hover:text-foreground"
          >
            <Headphones size={17} />
            {t.navSupport}
          </a>
          <button
            onClick={() => setLang(lang === "ru" ? "en" : "ru")}
            data-testid="button-nav-lang"
            className="flex flex-col items-center gap-1 px-3 py-1 text-[11px] text-muted-foreground hover:text-foreground"
          >
            <Globe size={17} />
            {lang.toUpperCase()}
          </button>
        </div>
      </nav>
    </div>
  );
}

function Pill({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-1.5 rounded-full border border-border bg-secondary/50 px-3.5 py-1.5 text-xs font-medium text-secondary-foreground">
      <span className="text-sky-400">{icon}</span>
      {label}
    </div>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <div className="text-2xl font-extrabold tracking-tight sm:text-3xl">{value}</div>
      <div className="mt-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground sm:text-[11px]">
        {label}
      </div>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  desc,
  bgIcon,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  bgIcon: React.ReactNode;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-card-border bg-card p-6">
      <div className="pointer-events-none absolute -right-3 -top-3 text-muted-foreground/10">
        {bgIcon}
      </div>
      <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/15 text-sky-400">
        {icon}
      </div>
      <h3 className="relative mt-4 text-[15px] font-bold">{title}</h3>
      <p className="relative mt-2 text-[13px] leading-relaxed text-muted-foreground">{desc}</p>
    </div>
  );
}

function StepCard({ num, title, desc }: { num: string; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-card-border bg-card p-6">
      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-xs font-bold text-muted-foreground">
        {num}
      </div>
      <h3 className="mt-4 text-[15px] font-bold">{title}</h3>
      <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{desc}</p>
    </div>
  );
}
